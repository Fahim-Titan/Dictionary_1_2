
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.io.PrintStream;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import org.w3c.dom.Document;
import org.w3c.dom.NodeList;

public class NewClass {

    public static void main(String args[]) {

        try {

            File file = new File("D:\\parse.xml");
            File word = new File("D:\\new.txt");
            File meaning = new File("D:\\Meaning.txt");
            
            BufferedWriter bwW = new BufferedWriter(new FileWriter(word));
            //BufferedWriter bwM = new BufferedWriter(new FileWriter(meaning));
            
            //File out = new File("D:\\parseXXX.xml");
            System.setOut(new PrintStream(word));
            DocumentBuilder dBuilder = DocumentBuilderFactory.newInstance().newDocumentBuilder();

            Document doc = dBuilder.parse(file);
            
            NodeList nodelist_of_ar = doc.getElementsByTagName("ar");
           // NodeList m = doc.getElementsByTagName("d");
            for(int i=0; i<nodelist_of_ar.getLength(); i++){
                //System.out.print("<entry>");
                System.out.print("@");
                System.out.print(nodelist_of_ar.item(i).getFirstChild().getTextContent());
                System.out.print("@");
                System.out.print("");
                System.out.print(nodelist_of_ar.item(i).getLastChild().getTextContent());
                System.out.print("#");
//                System.out.print("</entry>");
                System.out.println();
                
                //bwW.write(nodelist_of_ar.item(i).getFirstChild().getTextContent()+ "\n");
               /* 
                String s = m.item(i).getTextContent(); 
                String str = "";
     /*           if(s.charAt(0)==0xd)
                    str = s.
                bwM.write("\n");
                Hex*/
//                bwM.write(s+"\n");
            }
            
     //       
     /*       bwW.close();
            bwM.close();
       */     

        } catch (Exception e) {
            System.err.println(e);
        }
    }
}
